// pages/me/index.js
Page({
  data: {
    userInfo: {
      avatarUrl: '', // 默认为空
      nickName: ''
    },
    isAdmin: false,
    myOpenId: '点击获取'
  },

  onLoad: function() {
    // 读取缓存
    const ui = wx.getStorageSync('userInfo');
    if(ui) this.setData({ userInfo: ui });

    // 鉴权
    this.checkAdmin();
  },

  // ✨✨✨ 新功能：用户选择了头像 ✨✨✨
  onChooseAvatar(e) {
    const { avatarUrl } = e.detail;
    
    // 1. 更新页面显示
    const newUserInfo = { ...this.data.userInfo, avatarUrl: avatarUrl };
    this.setData({ userInfo: newUserInfo });
    
    // 2. 保存到缓存 (注意：这里的 avatarUrl 是临时路径，
    // 如果要永久保存，建议上传到云存储，但为了简单演示，先存本地)
    wx.setStorageSync('userInfo', newUserInfo);
  },

  // ✨✨✨ 新功能：用户输入了昵称 ✨✨✨
  onInputNickname(e) {
    const nickName = e.detail.value;
    const newUserInfo = { ...this.data.userInfo, nickName: nickName };
    this.setData({ userInfo: newUserInfo });
    wx.setStorageSync('userInfo', newUserInfo);
  },

  checkAdmin() {
    wx.cloud.callFunction({
      name: 'login', 
      success: res => {
        const currentOpenId = res.result.openid;
        this.setData({ myOpenId: currentOpenId });

        // 白名单
        const ADMIN_LIST = [
          'oZ6JU17tMbuDSmQGJ9yF2CYJRxvY', 
          'o6zAJs_家人A',
          'o6zAJs_家人B'
        ];

        if (ADMIN_LIST.includes(currentOpenId)) {
          this.setData({ isAdmin: true });
        }
      }
    });
  },

  copyId() {
    wx.setClipboardData({
      data: this.data.myOpenId,
      success: function() { wx.showToast({ title: '已复制', icon: 'success' }); }
    });
  },

  goToOrder(e) { wx.switchTab({ url: '/pages/order/index' }); },
  chooseAddress() { wx.chooseAddress({}); },
  goToAbout() { wx.navigateTo({ url: '/pages/about/about' }); },
  goToAdmin() { wx.navigateTo({ url: '/pages/admin/index' }); }
});
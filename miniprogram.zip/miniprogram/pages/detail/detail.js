// pages/detail/detail.js
//const db = wx.cloud.database();

Page({
  data: {
    goods: {},
    commentList: [],
    myComment: '',
    buyCount: 1 // ✨ 新增：默认买1个
  },

  onLoad: function (options) {
    if (options.goods) {
      try {
        const goods = JSON.parse(decodeURIComponent(options.goods));
        this.setData({ goods: goods });

        if (goods._id) {
          this.getComments(goods._id);
        }
      } catch (e) {
        console.error('解析商品数据失败:', e);
      }
    }
  },

  minusCount() {
    if (this.data.buyCount > 1) {
      this.setData({ buyCount: this.data.buyCount - 1 });
    }
  },

  // ✨✨✨ 新增：增加数量 ✨✨✨
  addCount() {
    this.setData({ buyCount: this.data.buyCount + 1 });
  },

  // ✨✨✨ 新增：加入购物车 ✨✨✨
  addToCart() {
    wx.showLoading({ title: '添加中' });
    const db = wx.cloud.database();

    // 🔍 1. 自动寻找正确的图片路径 (万能匹配)
    let finalImage = '';
    const g = this.data.goods;
    
    if (g.img) {
      finalImage = g.img; // 如果字段叫 img
    } else if (g.image) {
      finalImage = g.image; // 如果字段叫 image
    } else if (g.images && g.images.length > 0) {
      finalImage = g.images[0]; // 如果是 images 数组
    } else {
      // 如果实在找不到，就用一个默认图，或者留空
      finalImage = 'https://mmbiz.qpic.cn/mmbiz/icTdbqWNOwNQ0ia79fc42Mib4iaprj1W5kX71L8a2X6a2a/0'; 
    }

    // 2. 存入数据库
    db.collection('cart').add({
      data: {
        goods_id: g._id,
        name: g.name,
        price: g.price,
        
        // ✨ 这里用我们找到的 finalImage
        image: finalImage, 
        
        count: this.data.buyCount,
        createTime: new Date().getTime(),
        selected: true
      },
      success: res => {
        wx.hideLoading();
        wx.showToast({ title: '已加入购物车', icon: 'success' });
      },
      fail: err => {
        wx.hideLoading();
        console.error(err);
        wx.showToast({ title: '添加失败', icon: 'none' });
      }
    });
  },

  // 获取留言
  getComments(goodsId) {
    const db = wx.cloud.database();
    db.collection('comments').where({
      goods_id: goodsId 
    }).orderBy('createTime', 'desc').get({
      success: res => {
        const list = res.data.map(item => {
           let timeStr = '刚刚';
           if(item.createTime) {
             const d = new Date(item.createTime);
             // 简单格式化时间：月-日 时:分
             const m = (d.getMonth() + 1).toString().padStart(2, '0');
             const day = d.getDate().toString().padStart(2, '0');
             const h = d.getHours().toString().padStart(2, '0');
             const min = d.getMinutes().toString().padStart(2, '0');
             timeStr = `${m}-${day} ${h}:${min}`;
           }
           return { ...item, displayTime: timeStr };
        });
        this.setData({ commentList: list });
      }
    });
  },

 // 🛒 立即购买 (新版逻辑：先选地址 -> 再支付 -> 最后存单)
// ✨✨✨ 第一步：点击购买，先选地址 ✨✨✨
buyNow() {
  if (this.data.buyCount < 1) {
    wx.showToast({ title: '至少买一个', icon: 'none' });
    return;
  }

  const that = this;

  wx.chooseAddress({
    success: (addrRes) => {
      console.log('用户选了地址：', addrRes);
      
      // 1. 整理地址格式 (为了适配商家后台显示)
      const addressInfo = {
        userName: addrRes.userName,      // 姓名
        telNumber: addrRes.telNumber,    // 电话
        provinceName: addrRes.provinceName,
        cityName: addrRes.cityName,
        countyName: addrRes.countyName,
        detailInfo: addrRes.detailInfo,
        // 拼一个完整的字符串备用
        fullString: `${addrRes.provinceName}${addrRes.cityName}${addrRes.countyName}${addrRes.detailInfo}`
      };

      // 2. 去支付
      that.startPayment(addressInfo);
    },
    fail: (err) => {
      console.log('取消选地址', err);
    }
  });
},

// ✨✨✨ 第二步：发起支付 (核心修复：获取并传递订单号) ✨✨✨
startPayment(addressInfo) {
  wx.showLoading({ title: '正在下单...' });
  const that = this;
  
  // 计算总价 (分)
  const totalFee = Math.floor(this.data.goods.price * this.data.buyCount * 100);

  // 1. 呼叫云函数
  wx.cloud.callFunction({
    name: 'makeOrder',
    data: {
      goodsName: that.data.goods.name + ` x${that.data.buyCount}`,
      totalFee: totalFee
    },
    success: res => {
      const { payment, outTradeNo } = res.result; // <--- 关键：拿到了 outTradeNo
      
      // 2. 调起微信支付
      wx.requestPayment({
        ...payment,
        success: (payRes) => {
          console.log('支付成功，交易单号:', payRes.transactionId);
          
          // ✨✨✨ 第三步：存单 (把 两个关键单号 都传过去) ✨✨✨
          that.createOrder(addressInfo, outTradeNo, payRes.transactionId); 
        },
        fail: err => {
          wx.hideLoading();
          wx.showToast({ title: '支付已取消', icon: 'none' });
        }
      });
    },
    fail: err => {
      wx.hideLoading();
      console.error('下单云函数失败', err);
      wx.showToast({ title: '系统繁忙', icon: 'none' });
    }
  });
},

// ✨✨✨ 第四步：存入数据库 (核心修复：保存单号和正确格式) ✨✨✨
createOrder(addressInfo, outTradeNo, transactionId) {
  const db = wx.cloud.database();
  const g = this.data.goods;
  const totalFee = Math.floor(g.price * this.data.buyCount * 100);

  db.collection('orders').add({
    data: {
      // --- 1. 核心修复：必须保存这两个号，否则退不了款 ---
      out_trade_no: outTradeNo,       // 商户订单号
      transaction_id: transactionId,  // 微信交易单号
      
      // --- 2. 基础信息 ---
      createTime: new Date().getTime(),
      updateTime: new Date().toLocaleString(),
      status: 'PAID', // 统一用英文大写，匹配后台逻辑
      totalFee: totalFee, // 存“分”，避免小数计算误差
      totalPrice: (g.price * this.data.buyCount).toFixed(2), // 存“元”，用于展示
      
      // --- 3. 商品信息 ---
      goods_id: g._id,
      productName: g.name, // 统一叫 productName 方便后台看
      name: g.name,        // 兼容旧逻辑
      count: this.data.buyCount,
      price: g.price,
      image: g.image || g.img,

      // --- 4. 客户信息 (适配商家后台的 address 对象结构) ---
      address: {
        userName: addressInfo.userName,
        telNumber: addressInfo.telNumber,
        provinceName: addressInfo.provinceName,
        cityName: addressInfo.cityName,
        countyName: addressInfo.countyName,
        detailInfo: addressInfo.detailInfo
      },
      
      // --- 5. 其他 ---
      courier: '待发货',
      expressNo: '', // 统一用 expressNo
      remark: ''     // 备注清空，不要再存名字了
    },
    success: res => {
      wx.hideLoading();
      wx.showModal({
        title: '购买成功',
        content: '掌柜已收到您的订单，将尽快发货！',
        showCancel: false,
        success: () => {
           // 支付成功后跳到订单列表页
           wx.switchTab({ url: '/pages/order/index' });
        }
      });
    },
    fail: err => {
      wx.hideLoading();
      console.error('存单失败', err);
      wx.showModal({ title: '异常', content: '支付成功但订单保存失败，请截屏联系客服。' });
    }
  });
},

  // ✨✨✨ 核心修改：提交留言时使用真实头像 ✨✨✨
  submitComment() {
    if (!this.data.myComment.trim()) {
      wx.showToast({ title: '写点什么吧', icon: 'none' });
      return;
    }

    // 1. 尝试从缓存获取用户信息
    const ui = wx.getStorageSync('userInfo') || {};
    
    // 2. 决定用什么名字和头像
    // 如果缓存里有名字，就用缓存的；如果没有，就随机生成一个“食客+随机数”
    let finalNickName = ui.nickName;
    if (!finalNickName) {
      const randomNum = Math.floor(Math.random() * 1000);
      finalNickName = '食客' + randomNum;
    }

    // 如果缓存里有头像，就用缓存的；没有就留空(显示默认灰头像)
    let finalAvatar = ui.avatarUrl || '';

    wx.showLoading({ title: '提交中' });
    
    db.collection('comments').add({
      data: {
        content: this.data.myComment,
        goods_id: this.data.goods._id,
        createTime: new Date().getTime(),
        
        // 👇 这里不再是写死的了，而是变量
        nickName: finalNickName, 
        avatarUrl: finalAvatar,
        
        reply: '' 
      },
      success: res => {
        wx.hideLoading();
        wx.showToast({ title: '留言成功', icon: 'success' });
        this.setData({ myComment: '' });
        
        // 重新加载列表
        this.getComments(this.data.goods._id); 
      },
      fail: err => {
        wx.hideLoading();
        wx.showToast({ title: '提交失败', icon: 'none' });
      }
    });
  },

  onShareAppMessage() {
    return { title: this.data.goods.name }
  },
  // === 把这段代码粘贴进去 ===
  
  // 返回首页
  goHome() {
    // 1. 尝试跳转到 TabBar 页面 (通常首页是 TabBar)
    wx.switchTab({
      url: '/pages/index/index',
      fail: () => {
        // 2. 如果失败（说明首页不是 TabBar），则用 reLaunch 强行跳转
        wx.reLaunch({
          url: '/pages/index/index'
        });
      }
    });
  },

  // ========================
});
// pages/admin/index.js
const db = wx.cloud.database()

// ⚠️ 【配置区】在这里填入允许访问的管理员 OpenID
// 如果不知道自己的 OpenID，请运行一次代码，看控制台打印的 "当前用户OpenID"
const ADMIN_LIST = [
  "oZ6JU17tMbuDSmQGJ9yF2CYJRxvY",  // 您的微信号OpenID
  "oWwkw5yyyyyyyyyyyyyyyyyyyy"   // 其他合伙人的OpenID
];

Page({
  data: {
    isAdmin: false, // 是否是管理员
    stats: {
      todaySales: '0.00',
      yesterdaySales: '0.00',
      todayCount: 0,
      yesterdayCount: 0,
      pendingShip: 0,
      pendingRefund: 0
    },
    pendingOrders: [] 
  },

  onLoad() {
    // 页面加载时，先进行身份检查
    this.checkAuth();
  },

  onUnload() {
    if (this.watcher) this.watcher.close()
  },

  // === 1. 安全检查逻辑 ===
  checkAuth() {
    wx.showLoading({ title: '身份校验中...' })
    
    // 调用云函数获取当前用户的 OpenID
    // 假设您有一个名为 'login' 或 'getOpenId' 的云函数
    // 如果没有，请看代码下方的“补充说明”
    wx.cloud.callFunction({
      name: 'login', // 或者是 'quickStartFunctions'，取决于您的云函数目录
      data: {},
      success: res => {
        wx.hideLoading()
        // 获取 OpenID，不同云函数模板返回结构可能不同，这里做了兼容
        const openid = res.result.openid || res.result.event.userInfo.openId
        
        console.log('当前用户OpenID:', openid) // 方便您复制自己的ID

        if (ADMIN_LIST.includes(openid)) {
          // A. 验证通过：显示界面，开启数据监听
          this.setData({ isAdmin: true })
          this.startLiveWatch()
          wx.showToast({ title: '欢迎老板', icon: 'none' })
        } else {
          // B. 验证失败：踢出页面
          this.handleUnauthorized()
        }
      },
      fail: err => {
        wx.hideLoading()
        console.error('鉴权失败', err)
        wx.showModal({ title: '系统错误', content: '无法获取用户信息，请检查云函数' })
      }
    })
  },

  // 处理未授权用户
  handleUnauthorized() {
    wx.showModal({
      title: '无权访问',
      content: '该页面仅限商家内部访问。',
      showCancel: false,
      success: () => {
        // 强制跳转回首页
        wx.switchTab({ url: '/pages/index/index' }) 
        // 或者 wx.reLaunch({ url: '/pages/index/index' })
      }
    })
  },

  // === 2. 核心：开启实时监听 (验证通过后才执行) ===
  startLiveWatch() {
    const that = this
    this.watcher = db.collection('orders')
      .orderBy('createTime', 'desc')
      .limit(100)
      .watch({
        onChange: function(snapshot) {
          console.log('【数据同步】收到新变化:', snapshot)
          that.calculateStats(snapshot.docs)
        },
        onError: function(err) {
          console.error('监听失败:', err)
        }
      })
  },

  // === 数据计算逻辑（修正版） ===
  // pages/admin/index.js

  // === 数据计算逻辑（最终修复版） ===
  // pages/admin/index.js

  calculateStats(orders) {
    const todayStart = new Date(new Date().setHours(0,0,0,0)).getTime()
    
    let todaySales = 0
    let todayCount = 0
    let pendingShip = 0
    let pendingRefund = 0
    let list = [] 

    console.log('【调试】Admin收到数据:', orders) 

    orders.forEach(order => {
      // 1. 时间修复
      let orderTimeObj;
      if (order.createTime instanceof Date) {
        orderTimeObj = order.createTime;
      } else {
        orderTimeObj = new Date(order.createTime);
      }
      const ts = orderTimeObj.getTime();

      // 2. 金额修复
      if (!order.totalFee) {
          let rawPrice = order.price || order.money || order.total_fee || 0;
          if (String(rawPrice).indexOf('.') > -1) {
              order.totalFee = Math.round(Number(rawPrice) * 100);
          } else {
              order.totalFee = Number(rawPrice);
          }
      }
      
      // 3. 状态识别
      const statusStr = String(order.status || '').toUpperCase();
      const isPaid = statusStr.includes('PAID') || statusStr.includes('已支付');
      const hasExpress = order.expressNo && order.expressNo.length > 0;
      // 只要有快递号，或者是 SHIPPED 状态，都算已发货
      const isShipped = statusStr.includes('SHIPPED') || statusStr.includes('已发货') || hasExpress;
      const isRefunding = statusStr.includes('REFUNDING') || statusStr.includes('退款处理');

      // A. 统计看板
      if (ts >= todayStart && (isPaid || isShipped)) {
        todaySales += (order.totalFee || 0)
        todayCount++
      }

      // B. 生成“待处理列表” (关键修改！)
      // 如果是 (已支付且没发货) 或者 (正在申请退款)，都放进列表
      if ((isPaid && !hasExpress) || isRefunding) {
        
        // 专门给个显示的中文状态
        if (isRefunding) {
            order.displayStatus = '⚠️ 申请退款'; // 显眼一点
            pendingRefund++; // 计数+1
        } else {
            order.displayStatus = '待发货';
            pendingShip++;   // 计数+1
        }
        
        order.createTimeStr = orderTimeObj.toLocaleString()
        if(!order.address) order.address = { userName: '客户', telNumber: '' }
        
        list.push(order)
      }
    })

    this.setData({
      'stats.todaySales': (todaySales / 100).toFixed(2),
      'stats.todayCount': todayCount,
      'stats.pendingShip': pendingShip,
      'stats.pendingRefund': pendingRefund,
      pendingOrders: list
    })
  },

  // === 4. 操作按钮：退款 ===
  handleRefund(e) {
    const orderId = e.currentTarget.dataset.id
    wx.showModal({
      title: '⚠️ 确认退款',
      content: '资金将原路返回给客户，操作不可撤销。',
      confirmColor: '#ff4d4f',
      success: (res) => {
        if (res.confirm) {
          wx.showLoading({ title: '退款中...' })
          wx.cloud.callFunction({
            name: 'adminOrderOp',
            data: { action: 'refund', orderId: orderId },
            success: r => {
              wx.hideLoading()
              if(r.result.code === 0) {
                wx.showToast({ title: '退款成功' })
              } else {
                wx.showModal({ title: '失败', content: r.result.msg })
              }
            }
          })
        }
      }
    })
  },

  // === 5. 操作按钮：发货 ===
  handleShip(e) {
    const orderId = e.currentTarget.dataset.id
    wx.showModal({
      title: '填写快递单号',
      editable: true,
      placeholderText: '例如：SF12345678',
      success: (res) => {
        if (res.confirm && res.content) {
          wx.showLoading({ title: '发货中...' })
          wx.cloud.callFunction({
            name: 'adminOrderOp',
            data: { action: 'ship', orderId: orderId, expressNo: res.content },
            success: r => {
              wx.hideLoading()
              if(r.result.code === 0) wx.showToast({ title: '已发货' })
            }
          })
        }
      }
    })
  }
})
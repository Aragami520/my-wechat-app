// miniprogram/pages/index/index.js
Page({
  data: {
    // 您的真实轮播图
    bannerList: [
      'cloud://cloud1-3gwzyszw481ccd3d.636c-cloud1-3gwzyszw481ccd3d-1391405188/shop-images/banner1.jpg',
      'cloud://cloud1-3gwzyszw481ccd3d.636c-cloud1-3gwzyszw481ccd3d-1391405188/shop-images/banner2.jpg',
      'cloud://cloud1-3gwzyszw481ccd3d.636c-cloud1-3gwzyszw481ccd3d-1391405188/shop-images/banner3.jpg',
      'cloud://cloud1-3gwzyszw481ccd3d.636c-cloud1-3gwzyszw481ccd3d-1391405188/shop-images/banner4.jpg'
    ],
    
    // 您的真实商品数据 (注意：文件名里的空格我已经保留了)
    rawGoodsList: [
      { id: 1, name: '山西黑糯玉米', price: 29.9, unit: '箱(10根)', image: 'cloud://cloud1-3gwzyszw481ccd3d.636c-cloud1-3gwzyszw481ccd3d-1391405188/shop-images/corn-black.jpg', count: 0, desc: '口感软糯，花青素含量高' },
      { id: 2, name: '山西黄糯玉米', price: 29.9, unit: '箱(10根)', image: 'cloud://cloud1-3gwzyszw481ccd3d.636c-cloud1-3gwzyszw481ccd3d-1391405188/shop-images/corn-yellow.jpg', count: 0, desc: '香甜可口，老少皆宜' },
      { id: 3, name: '山西白糯玉米', price: 29.9, unit: '箱(10根)', image: 'cloud://cloud1-3gwzyszw481ccd3d.636c-cloud1-3gwzyszw481ccd3d-1391405188/shop-images/corn-white.jpg', count: 0, desc: '皮薄肉嫩，入口即化' },
      { id: 4, name: '山西花糯玉米', price: 29.9, unit: '箱(10根)', image: 'cloud://cloud1-3gwzyszw481ccd3d.636c-cloud1-3gwzyszw481ccd3d-1391405188/shop-images/fix corn.jpg', count: 0, desc: '双色口感，双重享受' },
      { id: 5, name: '玉米送礼礼盒', price: 39.9, unit: '箱(10根)', image: 'cloud://cloud1-3gwzyszw481ccd3d.636c-cloud1-3gwzyszw481ccd3d-1391405188/shop-images/box.jpg', count: 0, desc: '精美包装，送礼首选' },
      
      // 👇 测试翻页用的假数据 (如果您不想显示，可以删掉这两行)
      { id: 6, name: '测试商品6', price: 19.9, unit: '根', image: 'cloud://cloud1-3gwzyszw481ccd3d.636c-cloud1-3gwzyszw481ccd3d-1391405188/shop-images/corn-black.jpg', count: 0, desc: '凑数的' },
      { id: 7, name: '测试商品7', price: 19.9, unit: '根', image: 'cloud://cloud1-3gwzyszw481ccd3d.636c-cloud1-3gwzyszw481ccd3d-1391405188/shop-images/corn-yellow.jpg', count: 0, desc: '第二页的内容' }
    ],

    // 分页显示数据 (界面就靠它了！)
    displayGoodsPages: [],

    totalPrice: 0,
    totalCount: 0,
    name: '', phone: '', address: '', remark: '', showModal: false
  },

  // ✅ 页面加载
  onLoad() {
    this.initGoodsData(); // 必须运行这个函数，界面才会有东西！
    
    // 读取地址缓存
    const lastInfo = wx.getStorageSync('my_address_cache');
    if (lastInfo) {
      this.setData({
        name: lastInfo.name || '',
        phone: lastInfo.phone || '',
        address: lastInfo.address || ''
      });
    }
  },

  // ✅ 核心：切分数据函数
  initGoodsData() {
    const raw = this.data.rawGoodsList;
    const pages = [];
    // 6个一组进行切分
    for (let i = 0; i < raw.length; i += 6) {
      pages.push(raw.slice(i, i + 6));
    }
    this.setData({ displayGoodsPages: pages });
  },

  // 跳转详情页
  goToDetail(e) {
    const id = e.currentTarget.dataset.id;
    const item = this.data.rawGoodsList.find(i => i.id == id);
    if(item) {
        const itemStr = encodeURIComponent(JSON.stringify(item));
        wx.navigateTo({
          url: `/pages/detail/index?goods=${itemStr}`,
        });
    }
  },

  // 加购物车
  addCart(e) {
    const id = e.currentTarget.dataset.id;
    const rawList = this.data.rawGoodsList;
    const target = rawList.find(i => i.id == id);
    if(target) target.count++;
    
    this.setData({ rawGoodsList: rawList });
    this.initGoodsData(); // 刷新界面
    this.calcTotal();
  },

  // 减购物车
  subCart(e) {
    const id = e.currentTarget.dataset.id;
    const rawList = this.data.rawGoodsList;
    const target = rawList.find(i => i.id == id);
    if(target && target.count > 0) target.count--;
    
    this.setData({ rawGoodsList: rawList });
    this.initGoodsData(); // 刷新界面
    this.calcTotal();
  },

  calcTotal() {
    let sum = 0;
    let count = 0;
    this.data.rawGoodsList.forEach(item => {
      sum += item.price * item.count;
      count += item.count;
    });
    this.setData({
      totalPrice: sum.toFixed(2),
      totalCount: count
    });
  },

  // --- 支付相关 ---
  onInput(e) { this.setData({ [e.currentTarget.dataset.type]: e.detail.value }); },
  openPayModal() {
    if (this.data.totalCount === 0) return wx.showToast({ title: '请先选购商品', icon: 'none' });
    this.setData({ showModal: true });
  },
  closeModal() { this.setData({ showModal: false }); },
  
  confirmPay() {
    if (!this.data.name || !this.data.phone || !this.data.address) {
      return wx.showToast({ title: '请填写完整信息', icon: 'none' });
    }
    wx.setStorageSync('my_address_cache', { name: this.data.name, phone: this.data.phone, address: this.data.address });
    wx.showLoading({ title: '正在下单...' });

    const fee = Math.round(parseFloat(this.data.totalPrice) * 100);
    let buyDesc = ""; 
    this.data.rawGoodsList.forEach(item => {
      if(item.count > 0) buyDesc += `${item.name}x${item.count}; `;
    });
    if(this.data.remark) buyDesc += `(备注:${this.data.remark})`;

    wx.cloud.callFunction({
      name: 'makeOrder',
      data: { productName: '农家玉米合并下单', totalFee: fee },
      success: res => {
        wx.hideLoading();
        const payment = res.result.payment;
        if(!payment) {
           console.error("支付参数为空", res);
           // 避免商户号未授权导致报错卡住
           return wx.showToast({title:'请确认商户号已授权', icon:'none'});
        }
        wx.requestPayment({
          ...payment,
          success: () => {
            this.saveOrderToDB(buyDesc);
            const clearedList = this.data.rawGoodsList.map(i => ({...i, count:0}));
            this.setData({ showModal: false, rawGoodsList: clearedList }); 
            this.initGoodsData();
            this.calcTotal();
            wx.showToast({ title: '支付成功', icon: 'success' });
          },
          fail: (err) => console.error(err)
        })
      },
      fail: err => {
        wx.hideLoading();
        console.error(err);
      }
    });
  },
  saveOrderToDB(buyDesc) {
    const db = wx.cloud.database();
    db.collection('orders').add({
      data: {
        name: this.data.name, phone: this.data.phone, address: this.data.address, remark: this.data.remark,
        detail: buyDesc, totalPrice: this.data.totalPrice, createTime: db.serverDate(), status: 'PAID'
      }
    });
  }
});
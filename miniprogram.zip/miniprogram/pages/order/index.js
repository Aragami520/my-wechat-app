// pages/order/index.js
const app = getApp()
const db = wx.cloud.database()

Page({
  data: {
    orderList: [],
    isLoading: true
  },

  onShow() {
    this.getMyOrders()
  },

  // 获取订单
  getMyOrders() {
    wx.showLoading({ title: '加载中...' })
    db.collection('orders')
      .orderBy('createTime', 'desc')
      .get()
      .then(res => {
        wx.hideLoading()
        const formattedList = this.processOrders(res.data)
        this.setData({
          orderList: formattedList,
          isLoading: false
        })
      })
      .catch(err => {
        wx.hideLoading()
        console.error('获取订单失败', err)
        this.setData({ isLoading: false })
      })
  },

  // 处理数据（修复金额和时间）
  processOrders(list) {
    return list.map(item => {
      // 1. 修复金额
      if (!item.totalFee) {
        let rawPrice = item.price || item.money || item.total_fee || 0;
        if (String(rawPrice).indexOf('.') > -1) {
          item.totalFee = Math.round(Number(rawPrice) * 100);
        } else {
          item.totalFee = Number(rawPrice);
        }
      }

      // 2. 修复时间
      let dateObj = null;
      if (item.createTime) {
        dateObj = item.createTime instanceof Date ? item.createTime : new Date(item.createTime);
      }
      item.displayTime = dateObj ? dateObj.toLocaleString() : '未知时间';

      // 3. 状态默认值
      if (!item.status) item.status = 'PAID';

      return item;
    })
  },

  // 复制单号
  copyTracking(e) {
    const num = e.currentTarget.dataset.num
    if (!num) return;
    wx.setClipboardData({
      data: num,
      success: () => { wx.showToast({ title: '单号已复制', icon: 'none' }) }
    })
  },

  // 申请退款（核心修复：调用云函数）
  onApplyRefund(e) {
    const orderId = e.currentTarget.dataset.id
    wx.showModal({
      title: '申请退款',
      content: '商家审核通过后资金将原路返回，确认申请？',
      success: (res) => {
        if (res.confirm) {
          wx.showLoading({ title: '提交中...' })
          
          wx.cloud.callFunction({
            name: 'adminOrderOp',
            data: {
              action: 'apply_refund',
              orderId: orderId
            },
            success: res => {
              wx.hideLoading()
              if (res.result && res.result.code === 0) {
                wx.showToast({ title: '申请成功' })
                this.getMyOrders() // 刷新列表
              } else {
                wx.showToast({ title: res.result.msg || '提交失败', icon: 'none' })
              }
            },
            fail: err => {
              wx.hideLoading()
              console.error('云函数调用失败', err)
              wx.showToast({ title: '网络错误', icon: 'none' })
            }
          })
        }
      }
    })
  }
})
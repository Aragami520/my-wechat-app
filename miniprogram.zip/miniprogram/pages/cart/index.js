// pages/cart/index.js
//const db = wx.cloud.database();

Page({
  data: {
    cartList: [],
    totalPrice: 0,
    isAllSelected: true
  },

  onShow: function () {
    this.loadCart(); // 每次进页面都刷新
  },

  // 加载购物车数据
  loadCart() {
    const db = wx.cloud.database();
    db.collection('cart').orderBy('createTime', 'desc').get({
      success: res => {
        this.setData({ cartList: res.data });
        this.calculateTotal(); // 算钱
      }
    });
  },

  // 勾选/取消勾选某一个
  onCheckItem(e) {
    const index = e.currentTarget.dataset.index;
    const list = this.data.cartList;
    list[index].selected = !list[index].selected;
    this.setData({ cartList: list });
    this.calculateTotal();
    // 最好同步更新数据库，这里暂略，先做前端效果
  },

  // 全选
  onSelectAll() {
    const all = !this.data.isAllSelected;
    const list = this.data.cartList.map(item => {
      item.selected = all;
      return item;
    });
    this.setData({ cartList: list, isAllSelected: all });
    this.calculateTotal();
  },

  // 计算总价
  calculateTotal() {
    let total = 0;
    this.data.cartList.forEach(item => {
      if (item.selected) {
        total += item.price * item.count;
      }
    });
    this.setData({ totalPrice: total.toFixed(2) });
  },

  // 删除商品
  deleteItem(e) {
    const id = e.currentTarget.dataset.id;
    wx.showModal({
      title: '提示', content: '确定要把玉米移出购物车吗？',
      success: res => {
        if(res.confirm) {
          const db = wx.cloud.database();
          db.collection('cart').doc(id).remove({
             success: () => {
               this.loadCart(); // 删完刷新
             }
          });
        }
      }
    });
  },

  // 购物车结算 (这里比较复杂，暂时只做个样子)
  submitCart() {
    if (this.data.totalPrice == 0) {
      wx.showToast({ title: '还没选玉米呢', icon: 'none' });
      return;
    }
    // 真正的逻辑应该是：把选中的商品生成一个订单，然后调支付
    // 这里我们简单演示：调用之前的 makeOrder 支付总金额
    wx.showLoading({ title: '准备结算' });
    wx.cloud.callFunction({
      name: 'makeOrder',
      data: {
        goodsName: '购物车合并支付',
        totalFee: Math.floor(this.data.totalPrice * 100)
      },
      success: res => {
         wx.hideLoading();
         const payment = res.result.payment;
         wx.requestPayment({
           ...payment,
           success: () => { wx.showToast({ title: '支付成功' }) }
         });
      },
      fail: console.error
    });
  }
});